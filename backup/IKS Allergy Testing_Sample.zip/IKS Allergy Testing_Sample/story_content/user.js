function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6HwVKeURJLA":
        Script1();
        break;
      case "6G9Ew0yyWVg":
        Script2();
        break;
  }
}

function Script1()
{
  document.getElementById("reset").style.display = "none";
}

function Script2()
{
  document.getElementById("reset").style.display = "none";
}

